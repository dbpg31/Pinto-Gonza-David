package db;

public class Db {

	public Db(String string) {
	
	}

	public Db(String string, String string2, String string3, String string4, String string5) {

	}

	public void Sentencia(String format) {
		
	}

	public String[] getRegistro() {
		return null;
	}


}
